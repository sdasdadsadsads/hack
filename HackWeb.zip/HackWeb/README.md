วิธีติดตั้งอุปกรณ์
1 pkg upgrade
2 pkg install php 
3 pip install requests 
4 pip install -r requests 
วิธีใช้
1 ไปที่เก็บไฟล์
2 php hack.php ใส่URLเว็ป
